package com.balazsholczer.designpaterns.state;

public interface State {
	public void doAction(Context context);
}
