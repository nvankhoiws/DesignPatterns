package com.balazsholczer.solid;

public interface Vehicle {
	public void speed();
	public void addFuel();
}
