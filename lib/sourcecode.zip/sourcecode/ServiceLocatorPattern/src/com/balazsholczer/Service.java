package com.balazsholczer;

public interface Service {
	public String getName();
	public void execute();
}
