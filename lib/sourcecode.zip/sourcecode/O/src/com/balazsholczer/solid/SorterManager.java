package com.balazsholczer.solid;

public class SorterManager {

	public void sort(Sorter sorter) {
		sorter.sort();
	}
}
