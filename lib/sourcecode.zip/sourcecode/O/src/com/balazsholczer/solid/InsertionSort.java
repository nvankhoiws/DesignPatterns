package com.balazsholczer.solid;

public class InsertionSort implements Sorter {

	@Override
	public void sort() {
		System.out.println("Sorting with insertion sort...");
	}

}
