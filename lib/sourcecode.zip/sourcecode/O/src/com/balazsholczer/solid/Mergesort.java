package com.balazsholczer.solid;

public class Mergesort implements Sorter {

	@Override
	public void sort() {
		System.out.println("Sorting with mergesort...");
	}

}
