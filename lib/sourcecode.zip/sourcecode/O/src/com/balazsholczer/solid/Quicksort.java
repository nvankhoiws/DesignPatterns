package com.balazsholczer.solid;

public class Quicksort implements Sorter {

	@Override
	public void sort() {
		System.out.println("Doing quicksort...");
	}
}
