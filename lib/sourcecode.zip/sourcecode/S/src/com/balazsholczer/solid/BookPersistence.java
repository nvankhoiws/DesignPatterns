package com.balazsholczer.solid;

public class BookPersistence {

	public void save(Book book) {
		System.out.println("Saveing the book " + book);
	}
}
