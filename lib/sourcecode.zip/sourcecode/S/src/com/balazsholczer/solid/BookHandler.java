package com.balazsholczer.solid;

public interface BookHandler {
	public void save();
}
