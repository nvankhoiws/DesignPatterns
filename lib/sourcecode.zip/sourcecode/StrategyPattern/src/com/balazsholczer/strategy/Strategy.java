package com.balazsholczer.strategy;

public interface Strategy {
	public void operation(int num1, int num2);
}
