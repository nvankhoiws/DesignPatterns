package com.balazsholczer.solid;

public interface Database {
	public void connect();
	public void disconnect();
}
