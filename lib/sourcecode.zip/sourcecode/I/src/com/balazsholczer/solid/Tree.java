package com.balazsholczer.solid;

public interface Tree {
	public int findMax();
	public int findMin();
	public int traverse();
}
