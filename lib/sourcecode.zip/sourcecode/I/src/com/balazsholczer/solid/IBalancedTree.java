package com.balazsholczer.solid;

public interface IBalancedTree {
	public void rightRotation();
	public void leftRotation();
}
