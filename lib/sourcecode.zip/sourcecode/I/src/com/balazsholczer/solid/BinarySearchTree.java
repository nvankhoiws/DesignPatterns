package com.balazsholczer.solid;

public class BinarySearchTree implements Tree {

	@Override
	public int findMax() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int findMin() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int traverse() {
		// TODO Auto-generated method stub
		return 0;
	}

}
